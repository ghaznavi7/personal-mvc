﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace PersonalSite.Models
{
    public class Exprience
    {
        public byte Id { get; set; }

        [Required]
        [StringLength(255)]
        [Display(Name = "موقعیت")]
        public string Position { get; set; }

        [StringLength(255)]
        [Display(Name = "مکان")]
        public string Location { get; set; }

        [Display(Name = "توضیح")]
        public string Description { get; set; }

        [Display(Name = "تاریخ شروع")]
        public DateTime? StartDate { get; set; }

        [Display(Name = "تاریخ پایان")]
        public DateTime? EndDate { get; set; }
    }
}