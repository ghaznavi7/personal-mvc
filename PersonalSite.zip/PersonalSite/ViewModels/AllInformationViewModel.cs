﻿using PersonalSite.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PersonalSite.ViewModels
{
    public class AllInformationViewModel
    {
        public Person Person { get; set; }
        public List<Skill> Skills { get; set; }
        public List<Education> Educations { get; set; }
        public List<Exprience> Expriences { get; set; }
    }
}